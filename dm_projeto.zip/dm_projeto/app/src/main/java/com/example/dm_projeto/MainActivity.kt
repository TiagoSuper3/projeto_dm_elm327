package com.example.dm_projeto

import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var ligado = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val txtStatus = findViewById<TextView>(R.id.txtStatus)
        val btnAction = findViewById<Button>(R.id.btnAction)

        btnAction.setOnClickListener {
            if (!ligado) {
                // Alterna para o estado LIGADO (Verde)
                txtStatus.text = "Estado atual bluetooth:\nSeat Leon: Ligado"
                txtStatus.setTextColor(Color.parseColor("#2E7D32")) // Verde escuro
                btnAction.text = "Disconecte-se"
                btnAction.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#BDBDBD")))
                btnAction.setTextColor(Color.BLACK)
                ligado = true
            } else {
                // Volta ao estado DESLIGADO
                txtStatus.text = "Conecta-te ao bluetooth para acompanhares o teu amigo!"
                txtStatus.setTextColor(Color.BLACK)
                btnAction.text = "Conecta-te"
                btnAction.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.BLACK))
                btnAction.setTextColor(Color.WHITE)
                ligado = false
            }
        }
    }
}