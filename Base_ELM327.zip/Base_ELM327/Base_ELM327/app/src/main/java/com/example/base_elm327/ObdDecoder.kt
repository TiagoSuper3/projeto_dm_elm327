package com.example.base_elm327

object ObdDecoder {

    /** Extract bytes from responses with or without spaces, e.g. "41 0C 14 46>" or "410C1446>" */
    fun extractBytes(resp: String): List<Int> {
        val hex = resp.uppercase().filter { it in '0'..'9' || it in 'A'..'F' }

        val out = ArrayList<Int>(hex.length / 2)
        var i = 0
        while (i + 1 < hex.length) {
            val byteStr = "${hex[i]}${hex[i + 1]}"
            out.add(byteStr.toInt(16))
            i += 2
        }
        return out
    }

    /**
     * Finds the payload for a specific reply header, e.g. header [0x41, 0x0C] for RPM.
     * Returns bytes AFTER the header.
     */
    fun payloadAfterHeader(all: List<Int>, header: List<Int>): List<Int>? {
        if (all.size < header.size) return null
        for (i in 0..all.size - header.size) {
            var ok = true
            for (j in header.indices) {
                if (all[i + j] != header[j]) { ok = false; break }
            }
            if (ok) {
                return all.drop(i + header.size)
            }
        }
        return null
    }

    /** Decode supported PIDs from a response to 0100/0120/0140... */
    fun decodeSupportedPids(resp: String): Set<Int> {
        val bytes = extractBytes(resp)

        // Response looks like: 41 00 A B C D  (or 41 20 A B C D, etc.)
        // Find "41 xx" where xx is the base PID (00, 20, 40...)
        var idx = -1
        for (i in 0 until bytes.size - 1) {
            if (bytes[i] == 0x41) {
                idx = i
                break
            }
        }
        if (idx < 0 || idx + 5 >= bytes.size) return emptySet()

        val base = bytes[idx + 1] // 00, 20, 40...
        val a = bytes[idx + 2]
        val b = bytes[idx + 3]
        val c = bytes[idx + 4]
        val d = bytes[idx + 5]

        val mask = (a shl 24) or (b shl 16) or (c shl 8) or d

        val supported = mutableSetOf<Int>()
        // bit 31 -> base+1, bit 0 -> base+32
        for (bit in 0 until 32) {
            val isSet = (mask and (1 shl (31 - bit))) != 0
            if (isSet) supported.add(base + (bit + 1))
        }
        return supported
    }

    fun formatPidList(pids: Set<Int>): String =
        pids.sorted().joinToString(", ") { "0x" + it.toString(16).uppercase().padStart(2, '0') }

    /** 010C -> 41 0C A B */
    fun decodeRpm(resp: String): Int? {
        val bytes = extractBytes(resp)
        val payload = payloadAfterHeader(bytes, listOf(0x41, 0x0C)) ?: return null
        if (payload.size < 2) return null
        val a = payload[0]
        val b = payload[1]
        val rpm = ((a * 256) + b) / 4.0
        return kotlin.math.round(rpm).toInt()
    }

    /** 010D -> 41 0D A  (km/h) */
    fun decodeSpeed(resp: String): Int? {
        val bytes = extractBytes(resp)
        val payload = payloadAfterHeader(bytes, listOf(0x41, 0x0D)) ?: return null
        if (payload.isEmpty()) return null
        return payload[0]
    }

    /** 0105 -> 41 05 A  (°C = A - 40) */
    fun decodeCoolantTemp(resp: String): Int? {
        val bytes = extractBytes(resp)
        val payload = payloadAfterHeader(bytes, listOf(0x41, 0x05)) ?: return null
        if (payload.isEmpty()) return null
        return payload[0] - 40
    }

    /** 010F -> 41 0F A  (°C = A - 40) */
    fun decodeIntakeAirTemp(resp: String): Int? {
        val bytes = extractBytes(resp)
        val payload = payloadAfterHeader(bytes, listOf(0x41, 0x0F)) ?: return null
        if (payload.isEmpty()) return null
        return payload[0] - 40
    }

    /** 0111 -> 41 11 A  (% = A * 100 / 255) */
    fun decodeThrottlePos(resp: String): Int? {
        val bytes = extractBytes(resp)
        val payload = payloadAfterHeader(bytes, listOf(0x41, 0x11)) ?: return null
        if (payload.isEmpty()) return null
        val a = payload[0]
        return ((a * 100.0) / 255.0).toInt()
    }

    /** 010B -> 41 0B A  (kPa = A) */
    fun decodeManifoldPressure(resp: String): Int? {
        val bytes = extractBytes(resp)
        val payload = payloadAfterHeader(bytes, listOf(0x41, 0x0B)) ?: return null
        if (payload.isEmpty()) return null
        return payload[0]
    }

    /** 0110 -> 41 10 A B  (g/s = (A*256 + B) / 100) */
    fun decodeMaf(resp: String): Double? {
        val bytes = extractBytes(resp)
        val payload = payloadAfterHeader(bytes, listOf(0x41, 0x10)) ?: return null
        if (payload.size < 2) return null
        val a = payload[0]
        val b = payload[1]
        return ((a * 256) + b) / 100.0
    }

    /** Mode 09 PID 02 -> reply starts 49 02 xx ... VIN-as-ASCII ... */
    fun decodeVin(resp: String): String? {
        // 1) Keep only hex characters
        val hex = resp.uppercase().filter { it in '0'..'9' || it in 'A'..'F' }
        if (hex.length < 4) return null

        // 2) Convert to bytes
        val bytes = ArrayList<Int>(hex.length / 2)
        var i = 0
        while (i + 1 < hex.length) {
            bytes.add("${hex[i]}${hex[i + 1]}".toInt(16))
            i += 2
        }

        // 3) Find the "49 02" header anywhere in the stream
        var start = -1
        for (k in 0 until (bytes.size - 1)) {
            if (bytes[k] == 0x49 && bytes[k + 1] == 0x02) {
                start = k + 2
                break
            }
        }
        if (start < 0) return null

        // 4) VIN is printable ASCII after that header.
        // Some adapters include an extra byte right after 49 02 (frame/length),
        // so we just collect printable ASCII bytes.
        val vinChars = StringBuilder()
        for (k in start until bytes.size) {
            val b = bytes[k]
            if (b in 0x20..0x7E) vinChars.append(b.toChar())
        }

        // 5) Clean up: VIN is usually 17 chars; some emulators pad with zeros.
        val vin = vinChars.toString().trim().replace("\u0000", "")
        return vin.ifBlank { null }
    }

    /**
     * Decode DTCs from Mode 03 (stored) or Mode 07 (pending)
     * Response: 43 [A B] [A B] ... or 47 [A B] ...
     * Each DTC = 2 bytes.
     */
    fun decodeDtcs(resp: String, isPending: Boolean): List<String> {
        val bytes = extractBytes(resp)
        val header = if (isPending) listOf(0x47) else listOf(0x43)
        val payload = payloadAfterHeader(bytes, header) ?: return emptyList()

        // Some adapters return only "00" when none
        if (payload.all { it == 0x00 }) return emptyList()

        val out = mutableListOf<String>()
        var i = 0
        while (i + 1 < payload.size) {
            val a = payload[i]
            val b = payload[i + 1]
            i += 2

            if (a == 0x00 && b == 0x00) continue

            val dtc = decodeSingleDtc(a, b)
            out.add(dtc)
        }
        return out.distinct()
    }

    private fun decodeSingleDtc(a: Int, b: Int): String {
        // First two bits of A determine system:
        // 00=P, 01=C, 10=B, 11=U
        val system = when ((a and 0xC0) shr 6) {
            0 -> 'P'
            1 -> 'C'
            2 -> 'B'
            else -> 'U'
        }

        // Next two bits = first digit (0-3)
        val digit1 = ((a and 0x30) shr 4)

        // Next nibble = digit2
        val digit2 = (a and 0x0F)

        // B is last two digits in hex nibbles
        val digit3 = (b and 0xF0) shr 4
        val digit4 = (b and 0x0F)

        return buildString {
            append(system)
            append(digit1)
            append(digit2.toString(16).uppercase())
            append(digit3.toString(16).uppercase())
            append(digit4.toString(16).uppercase())
        }
    }
}
