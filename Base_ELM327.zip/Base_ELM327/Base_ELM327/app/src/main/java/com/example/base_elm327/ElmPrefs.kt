package com.example.base_elm327

import android.content.Context

object ElmPrefs {
    private const val PREFS = "elm_prefs"
    private const val KEY_ADDR = "last_device_addr"
    private const val KEY_NAME = "last_device_name"

    fun saveDevice(ctx: Context, addr: String, name: String?) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_ADDR, addr)
            .putString(KEY_NAME, name)
            .apply()
    }

    fun loadAddress(ctx: Context): String? =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_ADDR, null)

    fun loadName(ctx: Context): String? =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_NAME, null)
}
