package com.example.base_elm327

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import kotlin.concurrent.thread

class TroubleCodesFragment : Fragment(R.layout.fragment_trouble_codes) {

    private lateinit var textOutput: TextView
    private lateinit var client: ElmBluetoothClient

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        client = ElmConnectionManager.client
            ?: run {
                toast("Not connected")
                parentFragmentManager.popBackStack()
                return
            }

        textOutput = view.findViewById(R.id.textOutput)

        // ===== READ DTCs =====
        view.findViewById<Button>(R.id.btnReadDtcs).setOnClickListener {
            if (!ElmConnectionManager.isConnected()) {
                toast("Connection lost")
                parentFragmentManager.popBackStack()
                return@setOnClickListener
            }

            runJob {
                val stored = ObdDecoder.decodeDtcs(run("03"), isPending = false)
                val pending = ObdDecoder.decodeDtcs(run("07"), isPending = true)

                buildString {
                    appendLine("Stored DTCs:")
                    if (stored.isEmpty()) appendLine("  None")
                    else stored.forEach { appendLine("  $it") }

                    appendLine()
                    appendLine("Pending DTCs:")
                    if (pending.isEmpty()) appendLine("  None")
                    else pending.forEach { appendLine("  $it") }
                }
            }
        }

        // ===== CLEAR DTCs =====
        view.findViewById<Button>(R.id.btnClearDtcs).setOnClickListener {
            if (!ElmConnectionManager.isConnected()) {
                toast("Connection lost")
                parentFragmentManager.popBackStack()
                return@setOnClickListener
            }

            runJob {
                run("04")
                "Trouble codes cleared.\n(Re-read to confirm)"
            }
        }
    }

    // ================= HELPERS =================

    private fun run(cmd: String): String =
        client.sendAndWait(cmd, 3500)

    private fun runJob(job: () -> String) {
        thread {
            try {
                val result = job()
                if (!isAdded) return@thread
                requireActivity().runOnUiThread {
                    textOutput.text = result
                }
            } catch (e: Exception) {
                if (!isAdded) return@thread
                requireActivity().runOnUiThread {
                    textOutput.text = "Error: ${e.message}"
                }
            }
        }
    }

    private fun toast(msg: String) {
        if (!isAdded) return
        Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
    }
}
