package com.example.base_elm327

object ElmConnectionManager {

    private var _client: ElmBluetoothClient? = null

    val client: ElmBluetoothClient?
        get() = _client

    fun getOrCreate(
        onLog: (String) -> Unit,
        onData: (String) -> Unit
    ): ElmBluetoothClient {
        if (_client == null) {
            _client = ElmBluetoothClient(onLog, onData)
        }
        return _client!!
    }

    fun isConnected(): Boolean =
        _client?.isConnected() == true

    fun disconnect() {
        _client?.disconnect()
        _client = null
    }
}


