package com.example.base_elm327

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import kotlin.concurrent.thread

class VehicleInfoFragment : Fragment(R.layout.fragment_vehicle_info) {

    private lateinit var out: TextView
    private lateinit var client: ElmBluetoothClient

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        client = ElmConnectionManager.client
            ?: run {
                Toast.makeText(requireContext(), "Not connected", Toast.LENGTH_SHORT).show()
                // go back to Home fragment
                parentFragmentManager.beginTransaction()
                    .replace(R.id.fragmentContainer, HomeFragment())
                    .commit()
                return
            }

        out = view.findViewById(R.id.textOutput)

        // ===== READ BASIC INFO =====
        view.findViewById<Button>(R.id.btnReadBasic).setOnClickListener {
            if (!ElmConnectionManager.isConnected()) {
                toast("Connection lost")
                parentFragmentManager.beginTransaction()
                    .replace(R.id.fragmentContainer, HomeFragment())
                    .commit()
                return@setOnClickListener
            }

            runJob {
                val ati = run("ATI")
                val atdp = run("ATDP")
                val atrv = run("ATRV")
                val vinResp = run("0902")
                val vin = ObdDecoder.decodeVin(vinResp) ?: "N/A"

                val supported = readAllSupportedPids()

                """
                ELM: ${shortLine(ati)}
                Protocol: ${shortLine(atdp)}
                Voltage: ${shortLine(atrv)}
                VIN: $vin

                Supported PIDs (${supported.size}):
                ${ObdDecoder.formatPidList(supported)}
                """.trimIndent()
            }
        }

        // ===== READ LIVE SENSORS =====
        view.findViewById<Button>(R.id.btnReadSensors).setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, LiveSensorsFragment())
                .addToBackStack(null)
                .commit()
        }
    }

    // ================= HELPERS =================

    private fun readAllSupportedPids(): Set<Int> {
        val all = mutableSetOf<Int>()

        val r0100 = run("0100")
        val s0100 = ObdDecoder.decodeSupportedPids(r0100)
        all.addAll(s0100)

        if (0x20 in s0100) {
            val r0120 = run("0120")
            all.addAll(ObdDecoder.decodeSupportedPids(r0120))
        }

        return all
    }

    private fun shortLine(resp: String): String =
        resp.replace(">", "")
            .lines()
            .firstOrNull()
            ?.trim()
            .orEmpty()

    private fun run(cmd: String): String =
        client.sendAndWait(cmd, timeoutMs = 3500)

    private fun runJob(job: () -> String) {
        append("\n==== RESULT ====\n")
        thread {
            try {
                val result = job()
                requireActivity().runOnUiThread { append(result + "\n") }
            } catch (e: Exception) {
                requireActivity().runOnUiThread { append("Error: ${e.message}\n") }
            }
        }
    }

    private fun append(text: String) {
        out.append(text)
    }

    private fun toast(msg: String) {
        Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
    }
}
