package com.example.base_elm327

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import androidx.annotation.RequiresPermission
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.IOException
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

class ElmBluetoothClient(
    onLog: (String) -> Unit,
    onData: (String) -> Unit
) {
    @Volatile
    private var onLogCb: (String) -> Unit = onLog

    @Volatile
    private var onDataCb: (String) -> Unit = onData

    companion object {
        private val SPP_UUID: UUID =
            UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    }

    fun setCallbacks(
        onLog: (String) -> Unit,
        onData: (String) -> Unit
    ) {
        this.onLogCb = onLog
        this.onDataCb = onData
    }


    private var socket: BluetoothSocket? = null
    private var readerThread: Thread? = null
    private val running = AtomicBoolean(false)

    private val responseQueue = LinkedBlockingQueue<String>()

    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    @Synchronized
    fun connect(adapter: BluetoothAdapter, device: BluetoothDevice) {
        disconnect()

        onLogCb("Connecting to ${device.name} (${device.address}) ...")

        // IMPORTANT: discovery makes connect slow/unreliable
        adapter.cancelDiscovery()

        val s = device.createRfcommSocketToServiceRecord(SPP_UUID)
        try {
            s.connect()
        } catch (e: IOException) {
            try { s.close() } catch (_: IOException) {}
            throw e
        }

        socket = s
        onLogCb("Connected.")
        startReader()
    }

    @Synchronized
    fun disconnect() {
        running.set(false)
        readerThread?.interrupt()
        readerThread = null

        try { socket?.close() } catch (_: IOException) {}
        socket = null
    }

    fun isConnected(): Boolean = socket?.isConnected == true

    fun sendCommand(cmd: String) {
        val s = socket ?: throw IllegalStateException("Not connected")
        val out = BufferedOutputStream(s.outputStream)

        val payload = if (cmd.endsWith("\r")) cmd else "$cmd\r"
        onLogCb(">> ${payload.trim()}")
        out.write(payload.toByteArray(Charsets.US_ASCII))
        out.flush()
    }

    fun sendAndWait(cmd: String, timeoutMs: Long = 2500): String {
        responseQueue.clear()
        sendCommand(cmd)

        val start = System.currentTimeMillis()
        val sb = StringBuilder()

        while (System.currentTimeMillis() - start < timeoutMs) {
            val item = responseQueue.poll(300, TimeUnit.MILLISECONDS) ?: continue
            sb.append(item).append("\n")

            if (item.contains(">")) break
        }
        return sb.toString().trim()
    }

    private fun startReader() {
        val s = socket ?: return
        val input = BufferedInputStream(s.inputStream)

        running.set(true)
        readerThread = Thread {
            val buf = ByteArray(1024)
            val sb = StringBuilder()

            try {
                while (running.get() && !Thread.currentThread().isInterrupted) {
                    val n = input.read(buf)
                    if (n <= 0) break

                    sb.append(String(buf, 0, n, Charsets.US_ASCII))
                    var text = sb.toString()

                    // Emit responses when prompt '>' appears
                    while (true) {
                        val idx = text.indexOf('>')
                        if (idx < 0) break
                        val part = text.substring(0, idx + 1)
                        val cleaned = part.replace("\r", "").replace("\n", "").trim()
                        if (cleaned.isNotEmpty()) {
                            onDataCb(cleaned)
                            responseQueue.offer(cleaned)   // <-- ADD THIS LINE
                        }
                        text = text.substring(idx + 1)
                    }

                    sb.setLength(0)
                    sb.append(text)
                }
            } catch (e: IOException) {
                onLogCb("Reader stopped: ${e.message}")
            } finally {
                onLogCb("Disconnected.")
                disconnect()
            }
        }.also { it.start() }
    }
}

