package com.example.base_elm327

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import kotlin.concurrent.thread

class HomeFragment : Fragment(R.layout.fragment_home) {

    private val bt: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var txtConnectionStatus: TextView
    private lateinit var btnConnect: Button
    private lateinit var btnSend: Button
    private lateinit var editCommand: EditText
    private lateinit var textLog: TextView

    private lateinit var client: ElmBluetoothClient

    override fun onDestroyView() {
        super.onDestroyView()
        handler.removeCallbacksAndMessages(null)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        txtConnectionStatus = view.findViewById(R.id.txtConnectionStatus)
        btnConnect = view.findViewById(R.id.btnConnect)
        btnSend = view.findViewById(R.id.btnSend)
        editCommand = view.findViewById(R.id.editCommand)
        textLog = view.findViewById(R.id.textLog)

        ensurePermissions()

        // SINGLE global client
        client = ElmConnectionManager.getOrCreate(
            onLog = { requireActivity().runOnUiThread { appendLog(it) } },
            onData = { requireActivity().runOnUiThread { appendLog("<< $it") } }
        )

        // Delayed auto-reconnect (Samsung-safe)
        handler.postDelayed({
            if (isAdded) autoReconnectIfPossible()
        }, 1200)

        btnConnect.setOnClickListener {
            if (ElmConnectionManager.isConnected()) {
                disconnect()
            } else {
                manualConnect()
            }
        }

        btnSend.setOnClickListener {
            val cmd = editCommand.text?.toString()?.trim().orEmpty()
            if (cmd.isEmpty()) return@setOnClickListener

            thread {
                try {
                    val resp = client.sendAndWait(cmd, 3000)
                    requireActivity().runOnUiThread {
                        appendLog(">> $cmd")
                        appendLog(resp)
                    }
                } catch (e: Exception) {
                    requireActivity().runOnUiThread {
                        appendLog("Send error: ${e.message}")
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshUi()
    }

    // ================= CONNECTION =================

    private fun autoReconnectIfPossible() {
        if (ElmConnectionManager.isConnected()) {
            refreshUi()
            return
        }

        val adapter = bt ?: return
        if (!adapter.isEnabled) return

        val addr = ElmPrefs.loadAddress(requireContext()) ?: return
        val device = adapter.bondedDevices.firstOrNull { it.address == addr } ?: return

        appendLog("Auto-connecting to ${device.name ?: device.address}...")

        thread {
            try {
                connectToDevice(adapter, device)
                requireActivity().runOnUiThread { refreshUi() }
            } catch (e: Exception) {
                requireActivity().runOnUiThread {
                    appendLog("Auto-connect failed: ${e.message}")
                    refreshUi()
                }
            }
        }
    }

    private fun manualConnect() {
        val adapter = bt ?: run { toast("Bluetooth not supported"); return }
        if (!adapter.isEnabled) { toast("Enable Bluetooth"); return }

        val device = adapter.bondedDevices.firstOrNull()
            ?: run { toast("No paired device"); return }

        thread {
            try {
                connectToDevice(adapter, device)
                ElmPrefs.saveDevice(requireContext(), device.address, device.name)
                requireActivity().runOnUiThread { refreshUi() }
            } catch (e: Exception) {
                requireActivity().runOnUiThread {
                    appendLog("Connect error: ${e.message}")
                    refreshUi()
                }
            }
        }
    }

    private fun connectToDevice(adapter: BluetoothAdapter, device: BluetoothDevice) {
        client.connect(adapter, device)

        client.sendCommand("ATZ")
        client.sendCommand("ATE0")
        client.sendCommand("ATL0")
        client.sendCommand("ATS0")
        client.sendCommand("ATH0")
        client.sendCommand("ATI")
    }

    private fun disconnect() {
        ElmConnectionManager.disconnect()
        refreshUi()
        appendLog("Disconnected")
    }

    // ================= UI =================

    private fun refreshUi() {
        val connected = ElmConnectionManager.isConnected()

        btnSend.isEnabled = connected
        btnConnect.text = if (connected) "Disconnect" else "Connect"

        txtConnectionStatus.text =
            if (connected) {
                val name = ElmPrefs.loadName(requireContext()) ?: "Unknown device"
                "Connected to: $name"
            } else {
                "Not connected"
            }
    }

    // ================= HELPERS =================

    private fun appendLog(line: String) {
        textLog.append(line + "\n")

        textLog.post {
            val scroll = textLog.parent as ScrollView
            scroll.fullScroll(ScrollView.FOCUS_DOWN)
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
    }

    private fun ensurePermissions() {
        val perm = Manifest.permission.ACCESS_COARSE_LOCATION
        if (ActivityCompat.checkSelfPermission(requireContext(), perm)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                requireActivity(),
                arrayOf(perm),
                1001
            )
        }
    }
}
