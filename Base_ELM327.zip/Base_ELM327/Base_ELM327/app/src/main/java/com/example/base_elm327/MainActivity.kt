package com.example.base_elm327

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, HomeFragment())
                .addToBackStack(null)
                .commit()
        }

        // Bluetooth / Home
        findViewById<ImageButton>(R.id.btnBluetooth).setOnClickListener {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, HomeFragment())
                .commit()
        }

        findViewById<ImageButton>(R.id.btnVehicleInfo).setOnClickListener {
            if (!ElmConnectionManager.isConnected()) {
                toast("Connect first")
                return@setOnClickListener
            }

            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, VehicleInfoFragment())
                .commit()
        }

        findViewById<ImageButton>(R.id.btnVehicleTroubleCodes).setOnClickListener {
            if (!ElmConnectionManager.isConnected()) {
                toast("Connect first")
                return@setOnClickListener
            }

            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, TroubleCodesFragment())
                .commit()
        }
    }



    // ================= HELPERS =================

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
