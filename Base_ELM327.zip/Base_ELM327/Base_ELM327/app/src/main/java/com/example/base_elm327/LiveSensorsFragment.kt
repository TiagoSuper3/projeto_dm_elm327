package com.example.base_elm327

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import kotlin.concurrent.thread

class LiveSensorsFragment : Fragment(R.layout.fragment_live_sensors) {

    private lateinit var client: ElmBluetoothClient

    private lateinit var txtRpm: TextView
    private lateinit var txtSpeed: TextView
    private lateinit var txtCoolant: TextView
    private lateinit var txtAir: TextView
    private lateinit var txtThrottle: TextView
    private lateinit var txtMap: TextView
    private lateinit var txtMaf: TextView

    private val handler = Handler(Looper.getMainLooper())
    private val pollIntervalMs = 800L

    private val pollRunnable = object : Runnable {
        override fun run() {

            if (!isAdded || !ElmConnectionManager.isConnected()) return

            thread {
                try {
                    val rpm = ObdDecoder.decodeRpm(client.sendAndWait("010C"))
                    val speed = ObdDecoder.decodeSpeed(client.sendAndWait("010D"))
                    val coolant = ObdDecoder.decodeCoolantTemp(client.sendAndWait("0105"))
                    val air = ObdDecoder.decodeIntakeAirTemp(client.sendAndWait("010F"))
                    val throttle = ObdDecoder.decodeThrottlePos(client.sendAndWait("0111"))
                    val map = ObdDecoder.decodeManifoldPressure(client.sendAndWait("010B"))
                    val maf = ObdDecoder.decodeMaf(client.sendAndWait("0110"))

                    if (!isAdded) return@thread

                    handler.post {
                        if (!isAdded) return@post
                        updateUi(rpm, speed, coolant, air, throttle, map, maf)
                    }

                } catch (_: Exception) {
                    // ignore single poll failure
                }
            }

            handler.postDelayed(this, pollIntervalMs)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        client = ElmConnectionManager.client
            ?: run {
                toast("Not connected")
                parentFragmentManager.popBackStack()
                return
            }

        txtRpm = view.findViewById(R.id.txtRpm)
        txtSpeed = view.findViewById(R.id.txtSpeed)
        txtCoolant = view.findViewById(R.id.txtCoolant)
        txtAir = view.findViewById(R.id.txtAir)
        txtThrottle = view.findViewById(R.id.txtThrottle)
        txtMap = view.findViewById(R.id.txtMap)
        txtMaf = view.findViewById(R.id.txtMaf)

        // Initial placeholders (labels stay forever)
        updateUi(null, null, null, null, null, null, null)

        handler.post(pollRunnable)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        handler.removeCallbacksAndMessages(null)
    }

    // ================= UI =================

    private fun updateUi(
        rpm: Int?,
        speed: Int?,
        coolant: Int?,
        air: Int?,
        throttle: Int?,
        map: Int?,
        maf: Double?
    ) {
        txtRpm.text = "RPM: ${rpm ?: "--"} rpm"
        txtSpeed.text = "Speed: ${speed ?: "--"} km/h"
        txtCoolant.text = "Coolant: ${coolant ?: "--"} °C"
        txtAir.text = "Intake air: ${air ?: "--"} °C"
        txtThrottle.text = "Throttle: ${throttle ?: "--"} %"
        txtMap.text = "MAP: ${map ?: "--"} kPa"
        txtMaf.text = "MAF: ${maf?.let { String.format("%.2f", it) } ?: "--"} g/s"
    }

    private fun toast(msg: String) {
        if (!isAdded) return
        Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
    }
}
